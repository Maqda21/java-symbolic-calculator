package org.ioopm.calculator.ast;

import java.util.List;

public class FunctionDeclaration {
    String name; // The name of the function
    List<String> parameters; // List of parameter names
    List<SymbolicExpression> body; // List of expressions (function body)

    public FunctionDeclaration(String name, List<String> parameters, List<SymbolicExpression> body) {
        this.name = name;
        this.parameters = parameters;
        this.body = body;
    }

    // Getters and setters as needed
    public String getName() {
        return name;
    }

    public List<String> getParameters() {
        return parameters;
    }

    public List<SymbolicExpression> getBody() {
        return body;
    }
}
