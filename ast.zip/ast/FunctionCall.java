package org.ioopm.calculator.ast;

import java.util.List;

public class FunctionCall {
    String name; // The name of the function being called
    List<SymbolicExpression> arguments; // List of argument expressions

    public FunctionCall(String name, List<SymbolicExpression> arguments) {
        this.name = name;
        this.arguments = arguments;
    }

    // Getters and setters
    public String getName() {
        return name;
    }

    public List<SymbolicExpression> getArguments() {
        return arguments;
    }
}
