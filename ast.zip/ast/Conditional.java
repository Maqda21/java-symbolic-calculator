package org.ioopm.calculator.ast;

public class Conditional extends SymbolicExpression {
    private final SymbolicExpression condition;
    private final SymbolicExpression trueBranch;
    private final SymbolicExpression falseBranch;

    public Conditional(SymbolicExpression condition, SymbolicExpression trueBranch, SymbolicExpression falseBranch) {
        this.condition = condition;
        this.trueBranch = trueBranch;
        this.falseBranch = falseBranch;
    }

    public SymbolicExpression getCondition() {
        return condition;
    }

    public SymbolicExpression getTrueBranch() {
        return trueBranch;
    }

    public SymbolicExpression getFalseBranch() {
        return falseBranch;
    }

    @Override
    public SymbolicExpression accept(Visitor visitor) {
        // We pass the Conditional instance to the correct visit method for it
        return visitor.visit(this);
    }
}
