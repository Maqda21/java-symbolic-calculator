package org.ioopm.calculator.ast;

import java.util.ArrayList;
import java.util.List;

public class NamedConstantChecker implements Visitor {
    private List<String> illegalAssignments = new ArrayList<>();

    public SymbolicExpression visit(Addition a) {
        a.getLhs().accept(this);
        a.getRhs().accept(this);
        return null;
    }

    public SymbolicExpression visit(Assignment a) {
        a.getLhs().accept(this);
        a.getRhs().accept(this);
        if (a.getRhs() instanceof Constant) {
            Constant rhs = (Constant) a.getRhs();
            if (rhs.getName() != null && !rhs.getName().isEmpty()) {
                illegalAssignments.add(a.getLhs() + " = " + a.getRhs());
            }
        }
        return null;
    }

    public SymbolicExpression visit(Clear n) {
        return null;
    }

    public SymbolicExpression visit(Constant n) {
        return null;
    }

    public SymbolicExpression visit(Cos n) {
        n.getOperand().accept(this);
        return null;
    }

    public SymbolicExpression visit(Division n) {
        n.getLhs().accept(this);
        n.getRhs().accept(this);
        return null;
    }

    public SymbolicExpression visit(Exp n) {
        n.getOperand().accept(this);
        return null;
    }

    public SymbolicExpression visit(Log n) {
        n.getOperand().accept(this);
        return null;
    }

    public SymbolicExpression visit(Multiplication n) {
        n.getLhs().accept(this);
        n.getRhs().accept(this);
        return null;
    }

    public SymbolicExpression visit(Negation n) {
        n.getOperand().accept(this);
        return null;
    }

    public SymbolicExpression visit(Quit n) {
        return null;
    }

    public SymbolicExpression visit(Sin n) {
        n.getOperand().accept(this);
        return null;
    }

    public SymbolicExpression visit(Subtraction n) {
        n.getLhs().accept(this);
        n.getRhs().accept(this);
        return null;
    }

    public SymbolicExpression visit(Variable n) {
        return null;
    }

    public SymbolicExpression visit(Vars n) {
        return null;
    }

    // Visit method for Conditional
    public SymbolicExpression visit(Conditional c) {
        // Visit the condition expression
        c.getCondition().accept(this);

        // Visit the true branch
        c.getTrueBranch().accept(this);

        // Visit the false branch
        c.getFalseBranch().accept(this);

        return null;
    }

    public List<String> getIllegalAssignments() {
        return illegalAssignments;
    }
}
    
        
        

        
         

        
         

        
    