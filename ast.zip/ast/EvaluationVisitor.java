package org.ioopm.calculator.ast;

import org.ioopm.calculator.parser.IllegalAssignmentException;
import java.util.ArrayList;
import java.util.List;

public class EvaluationVisitor implements Visitor {
    private Environment env = null;
    private List<String> illegalAssignments = new ArrayList<>(); // Track illegal assignments

    public SymbolicExpression evaluate(SymbolicExpression topLevel, Environment env) {
        this.env = env;
        return topLevel.accept(this);
    }

    // This method gets called from Addition.accept(Visitor v) -- you should
    // be able to see from the eval() methods how these should behave (i.e.,
    // compare this method with your Addition::eval() and Symbolic.addition)
    public SymbolicExpression visit(Addition n) {
        // Visit the left-hand side and right-hand side subexpressions
        SymbolicExpression left = n.getLhs().accept(this);
        SymbolicExpression right = n.getRhs().accept(this);

        // If subexpressions are fully evaluated, replace them in
        // the tree with a constant whose value is the sum of the
        // subexpressions, if not, simply construct a new addition
        // node from the new subexpressions
        if (left.isConstant() && right.isConstant()) {
            return new Constant(left.getValue() + right.getValue());
        } else {
            return new Addition(left, right);
        }
    }

    @Override
    public SymbolicExpression visit(Assignment assignment) {
        // Evaluate the left-hand side using the visitor
        SymbolicExpression lhsValue = assignment.getLhs().accept(this);

        // Validate that the right-hand side is a Variable
        if (!(assignment.getRhs() instanceof Variable)) {
            throw new RuntimeException("The right-hand side of an assignment must be a variable");
        }

        // Prevent reassignment of named constants
        if (lhsValue instanceof NamedConstant) {
            NamedConstant nc = (NamedConstant) lhsValue;
            // Track the illegal assignment
            illegalAssignments.add("Cannot redefine constant: " + nc.getName());
            throw new IllegalAssignmentException("Error: cannot redefine named constant '" + nc.getName() + "'");
        }

        // Bind the evaluated left-hand side to the variable in the environment
        Variable variable = (Variable) assignment.getRhs();
        env.put(variable, lhsValue);

        // Return the evaluated left-hand side
        return lhsValue;
    }

    @Override
    public SymbolicExpression visit(Clear clear) {
        if (env != null) {
            env.clearCurrentScope(); // Clear all variable bindings from the environment
        }
        return clear; // Return the Clear instance itself or another appropriate value
    }

    @Override
    public SymbolicExpression visit(Constant constant) {
        return constant; // A constant evaluates to itself
    }

    @Override
    public SymbolicExpression visit(Cos cos) {
        SymbolicExpression arg = cos.getOperand().accept(this);
        if (arg.isConstant()) {
            return new Constant(Math.cos(arg.getValue()));
        } else {
            return new Cos(arg);
        }
    }

    @Override
    public SymbolicExpression visit(Division division) {
        SymbolicExpression left = division.getLhs().accept(this);
        SymbolicExpression right = division.getRhs().accept(this);

        if (left.isConstant() && right.isConstant()) {
            if (right.getValue() == 0) {
                throw new ArithmeticException("Division by zero");
            }
            return new Constant(left.getValue() / right.getValue());
        } else {
            return new Division(left, right);
        }
    }

    @Override
    public SymbolicExpression visit(Exp exp) {
        SymbolicExpression arg = exp.getOperand().accept(this);

        if (arg.isConstant()) {
            return new Constant(Math.exp(arg.getValue()));
        } else {
            return new Exp(arg);
        }
    }

    @Override
    public SymbolicExpression visit(Log log) {
        SymbolicExpression arg = log.getOperand().accept(this);

        if (arg.isConstant()) {
            if (arg.getValue() <= 0) {
                throw new ArithmeticException("Logarithm of non-positive number is undefined");
            }
            return new Constant(Math.log(arg.getValue()));
        } else {
            return new Log(arg);
        }
    }

    @Override
    public SymbolicExpression visit(Multiplication multiplication) {
        SymbolicExpression left = multiplication.getLhs().accept(this);
        SymbolicExpression right = multiplication.getRhs().accept(this);

        if (left.isConstant() && right.isConstant()) {
            return new Constant(left.getValue() * right.getValue());
        } else {
            return new Multiplication(left, right);
        }
    }

    @Override
    public SymbolicExpression visit(Negation negation) {
        SymbolicExpression arg = negation.getOperand().accept(this);

        if (arg.isConstant()) {
            return new Constant(-arg.getValue());
        } else {
            return new Negation(arg);
        }
    }

    @Override
    public SymbolicExpression visit(Quit quit) {
        System.exit(0); // This will exit the program
        return null;
    }

    @Override
    public SymbolicExpression visit(Sin sin) {
        SymbolicExpression arg = sin.getOperand().accept(this);
        if (arg.isConstant()) {
            return new Constant(Math.sin(arg.getValue()));
        } else {
            return new Sin(arg);
        }
    }

    @Override
    public SymbolicExpression visit(Subtraction subtraction) {
        SymbolicExpression left = subtraction.getLhs().accept(this);
        SymbolicExpression right = subtraction.getRhs().accept(this);

        if (left.isConstant() && right.isConstant()) {
            return new Constant(left.getValue() - right.getValue());
        }
        return new Subtraction(left, right);
    }

    @Override
    public SymbolicExpression visit(Variable variable) {
        if (env.containsKey(variable)) {
            return env.get(variable).accept(this); // Recursively accept the visitor on the value of the variable
        } else {
            return variable; // Return the variable itself if not found in the environment
        }
    }

    @Override
    public SymbolicExpression visit(Vars vars) {
        // List all variables in the environment
        StringBuilder variableList = new StringBuilder("Variables: ");
        for (Variable var : env.keySet()) {
            variableList.append(var.getName()).append(" ");
        }
        System.out.println(variableList.toString().trim()); // Print the variable list
        return null;
    }

    @Override
    public SymbolicExpression visit(Conditional conditional) {
        // First, evaluate the condition
        SymbolicExpression condition = conditional.getCondition().accept(this);

        // Check if the condition is a constant (this is assuming the condition is
        // always evaluated to a constant value)
        if (!condition.isConstant()) {
            throw new RuntimeException("Condition of an if-expression must evaluate to a constant value");
        }

        // If the condition is true, evaluate the trueBranch; otherwise, evaluate the
        // falseBranch
        if (condition.getValue() != 0) { // Non-zero value is considered true
            return conditional.getTrueBranch().accept(this);
        } else {
            return conditional.getFalseBranch().accept(this);
        }
    }

    public boolean check(SymbolicExpression expr) {
        illegalAssignments.clear();
        expr.accept(this);
        if (!illegalAssignments.isEmpty()) {
            System.out.println("Error, assignments to named constants:");
            for (String assignment : illegalAssignments) {
                System.out.println("    " + assignment);
            }
            return false;
        } else {
            return true;
        }
    }
}
