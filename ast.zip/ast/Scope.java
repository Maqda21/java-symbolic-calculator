package org.ioopm.calculator.ast;

import java.util.List;

public class Scope {
    private final List<Object> statements; // List of statements inside the scope

    public Scope(List<Object> statements) {
        this.statements = statements;
    }

public List<Object> getStatements() {
            return statements;
}
}